package com.domain.controller.HackerNewAPI;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HackerNewApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
