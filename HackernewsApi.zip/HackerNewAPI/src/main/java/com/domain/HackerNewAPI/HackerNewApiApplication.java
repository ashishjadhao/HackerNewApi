package com.domain.HackerNewAPI;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HackerNewApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(HackerNewApiApplication.class, args);
	}

}
